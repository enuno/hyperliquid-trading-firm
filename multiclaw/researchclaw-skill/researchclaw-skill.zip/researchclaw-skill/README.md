# ResearchClaw Skill for Claude Code

**Turn Claude Code into a one-command autonomous research paper generator.**

This skill wraps [AutoResearchClaw](https://github.com/aiming-lab/AutoResearchClaw) — the 23-stage pipeline that takes a research topic and produces a conference-grade LaTeX paper with real citations, sandbox experiments, multi-agent peer review, and citation verification.

[English](#quick-start) | [中文](docs/zh-CN/README.md)

---

## Why This Exists

AutoResearchClaw is powerful but painful to set up. It requires Python 3.11+, Docker, LaTeX, complex YAML configuration, and careful dependency management. Over 55 issues were filed in the first 5 days — most about setup failures, config confusion, and Stage 10 crashes.

This skill solves that by giving you:

- **`/researchclaw:setup`** — Detects and installs all prerequisites with one command
- **`/researchclaw:config`** — Interactive wizard that generates a working config.yaml
- **`/researchclaw:run`** — Pre-flight validation + pipeline execution + auto-diagnosis
- **`/researchclaw:diagnose`** — Pattern-matched error detection with concrete fixes
- **3 custom hooks** — Auto-diagnosis on errors, config backup on writes, artifact deletion protection
- **Honest error reporting** — No fabricated capabilities, no hidden failures

## Quick Start

### 1. Install the skill

Copy the `.claude/` directory into your project root:

```bash
# Clone this repo
git clone https://github.com/YOUR_USERNAME/researchclaw-skill.git

# Copy skill files into your project
cp -r researchclaw-skill/.claude your-project/
```

Or install directly into an existing project:

```bash
mkdir -p .claude/skills
cp -r researchclaw-skill/.claude/skills/researchclaw .claude/skills/
cp researchclaw-skill/.claude/hooks.json .claude/
```

### 2. Open Claude Code and run setup

```
/researchclaw:setup
```

Claude will check every dependency and tell you exactly what is missing and how to install it.

### 3. Generate your config

```
/researchclaw:config
```

Answer the interactive questions. You will need:
- A research topic
- An LLM API key (OpenAI, Anthropic, DeepSeek, etc.)
- Your preferred experiment mode (simulated is fastest for first runs)

### 4. Run the pipeline

```
/researchclaw:run Your research topic here
```

Or just `/researchclaw:run` to use the topic from your config.

### 5. Check status

```
/researchclaw:status
```

## Commands

| Command | What It Does |
|---|---|
| `/researchclaw` | Show help and available subcommands |
| `/researchclaw:setup` | Check and install all prerequisites |
| `/researchclaw:config` | Interactive config wizard |
| `/researchclaw:run` | Start a research pipeline run |
| `/researchclaw:status` | Check pipeline progress (X/23 stages) |
| `/researchclaw:resume` | Resume from last successful stage |
| `/researchclaw:diagnose` | Auto-detect and explain failures |
| `/researchclaw:validate` | Pre-run validation checklist |

## Custom Hooks

This skill includes 3 Claude Code hooks that run automatically:

| Hook | Type | What It Does |
|---|---|---|
| Post-run check | PostToolUse | Scans output of any `researchclaw` command for error patterns and surfaces auto-diagnosis |
| Config backup | PreToolUse | Backs up `config.yaml` before any overwrite to prevent data loss |
| Artifact guard | PreToolUse | Blocks accidental deletion of `artifacts/` directory |
| Completion notify | Notification | Logs pipeline completion/failure and sends desktop notification (if available) |

## What This Skill Does NOT Do

Honesty is a core principle. This skill:

- **Does not start Docker** — It checks if Docker is running, but cannot start the daemon for you
- **Does not provide API keys** — You must supply your own LLM API keys
- **Does not fix network issues** — If your firewall blocks arXiv or Semantic Scholar, the skill will tell you but cannot fix it
- **Does not guarantee paper quality** — The output depends on the LLM model, topic complexity, and experiment mode
- **Does not modify upstream code** — It wraps the official AutoResearchClaw CLI, not a fork

## Project Structure

```
.claude/
├── hooks.json                          # Claude Code hooks configuration
└── skills/
    └── researchclaw/
        ├── SKILL.md                    # Main skill definition (Claude reads this)
        ├── assets/
        │   └── config-template.yaml    # Config generation template
        ├── references/
        │   ├── pipeline-stages.md      # All 23 stages documented
        │   ├── config-reference.md     # Every config field explained
        │   ├── troubleshooting.md      # Common failures and fixes
        │   └── README-CN.md           # Chinese documentation
        └── scripts/
            ├── check-prereqs.sh        # Prerequisite detection (JSON output)
            ├── post-run-check.sh       # PostToolUse error scanner
            ├── pre-config-write.sh     # PreToolUse config backup
            ├── pre-delete-guard.sh     # PreToolUse artifact protection
            └── notify-completion.sh    # Notification on completion
tests/
└── test-skill.sh                       # 58-test self-validation suite
docs/
└── zh-CN/
    └── README.md                       # Full Chinese documentation
```

## Testing

Run the self-validation test suite:

```bash
cd your-project
bash tests/test-skill.sh
```

The test suite validates:
- File structure completeness (21 checks)
- Content quality — all commands documented, honesty policy present, limitations stated (20 checks)
- Script syntax validity (5 checks)
- Hooks configuration correctness (4 checks)
- Config template validity (8 checks)

**Current status: 58/58 tests passing.**

## System Requirements

| Component | Required | Notes |
|---|---|---|
| Python | 3.11+ | Core requirement |
| pip or uv | Yes | Package installation |
| Git | Yes | Cloning upstream repo |
| Docker | For sandbox mode | Not needed for simulated mode |
| LaTeX | For PDF output | texlive-full recommended |
| RAM | 16 GB minimum | 32 GB+ recommended |
| Disk | 10 GB free | 50 GB+ for large runs |
| Network | Yes | API calls + literature search |

## Upstream Compatibility

This skill targets **AutoResearchClaw v0.3.x** ([aiming-lab/AutoResearchClaw](https://github.com/aiming-lab/AutoResearchClaw)). If the upstream project changes significantly, some commands may need updating. The skill will warn you if it detects a version mismatch.

## Contributing

Contributions welcome. Please:
1. Run `bash tests/test-skill.sh` before submitting
2. Ensure all 58 tests pass
3. Add tests for any new functionality
4. Keep the honesty policy — never fabricate capabilities

## License

MIT — same as AutoResearchClaw upstream.

---

**Built with respect for [AutoResearchClaw](https://github.com/aiming-lab/AutoResearchClaw) by aiming-lab and inspired by [Karpathy's autoresearch](https://github.com/karpathy/autoresearch) philosophy.**
